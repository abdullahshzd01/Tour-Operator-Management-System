package BL;

public class PayByEasypaisaAdapter extends PaymentHandler{

	
	public boolean makePayment(Payment payment) {
		
		//call to external API
		//...
		
		return true;
		
	}
	
}
