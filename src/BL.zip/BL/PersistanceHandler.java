package BL;

public class PersistanceHandler {
	
	public boolean storeInfo(Client c) {
		
		return true;
		
	}

	public boolean storeInfo(Tour t) {
		
		return true;
		
	}
	
	public boolean storeInfo(Reservation r) {
		
		return true;
		
	}
	
}
