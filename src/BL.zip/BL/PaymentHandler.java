package BL;

public class PaymentHandler {
	
	public boolean makePayment(Payment payment) {
		
		//call to external API
		//...
		
		return true;
		
	}
	
}
