package BL;

public class OracleDBStorage extends PersistanceHandler{

}
