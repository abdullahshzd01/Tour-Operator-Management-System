package BL;

public class PayByCardAdapter extends PaymentHandler{

	public boolean makePayment(Payment payment) {
		
		//call to external API
		//...
		
		return true;
		
	}
	
}
