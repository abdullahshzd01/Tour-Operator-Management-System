package BL;

public class Reciept {
	
	//think where it fits

}
