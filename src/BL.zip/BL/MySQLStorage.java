package BL;

public class MySQLStorage extends PersistanceHandler{

}
