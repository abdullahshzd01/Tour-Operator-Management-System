package BL;

public class PayByCash extends PaymentHandler{

	public boolean makePayment(Payment payment) {
		
		//call to external API
		//...
		
		return true;
		
	}
	
	
}
